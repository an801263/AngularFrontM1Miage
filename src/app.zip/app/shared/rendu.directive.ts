import { Directive } from '@angular/core';

@Directive({
    selector: '[AppRendu]'
})

export class RenduDirective {
    constructor()
    {

    }
}