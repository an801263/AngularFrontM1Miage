import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-assignments',
  templateUrl: './assignments.component.html',
  styleUrls: ['./assignments.component.css'],
})

export class AssignmentsComponent implements OnInit {
  titre = 'Gestion des assignments';
  ajoutActive = false;
  nomDevoir:string = "";

  ngOnInit(): void {
    setTimeout(()=> {
      this.ajoutActive = true;
    }, 2000);
  }
  
  onSubmit(event:any) {
    console.log(event);
  }

  assignments = [
    {
      nom: 'Devoir WebComponents lecteur video',
      dateDeRendu: '2021-11-07',
      rendu: true,
    },
    {
      nom: 'Devoir Angular en binôme',
      dateDeRendu: '2021-12-18',
      rendu: false,
    },
    {
      nom: 'Devoir App Mobile cross platform',
      dateDeRendu: '2021-12-03',
      rendu: false,
    },
  ];
  constructor() {}

  getColor(a: any) {
     return a.rendu ? 'green' : 'red';
  }
}
