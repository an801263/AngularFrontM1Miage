export class Assignment {
    nom!:string;
    dateDeRendu!:Date;
    rendu!:boolean;
}